void setup() {
  pinMode(13, OUTPUT); // Red
  pinMode(12, OUTPUT); // Yellow
  pinMode(11, OUTPUT); // Green
}

void loop() {
  digitalWrite(13, HIGH);   // Red ON
  delay(9000);              // 3 sec
  digitalWrite(13, LOW);    // Red OFF

  digitalWrite(12, HIGH);   // Yellow ON
  delay(3000);
  digitalWrite(12, LOW);    // Yellow OFF

  digitalWrite(11, HIGH);   // Green ON
  delay(9000);
  digitalWrite(11, LOW);    // Green OFF
}
